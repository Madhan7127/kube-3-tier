package com.spidy.spidy_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpidyBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
