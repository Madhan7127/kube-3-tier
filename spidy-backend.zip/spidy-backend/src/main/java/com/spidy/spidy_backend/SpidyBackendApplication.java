package com.spidy.spidy_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpidyBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpidyBackendApplication.class, args);
	}

}
